return {
    "Manager.CfgManager",
    --"Manager.NetworkManager",
    "Manager.UIManager",
    "Manager.SceneManager",
}