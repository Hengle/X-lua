return {
    "http://39.104.102.223:41401/LSWJJFileServer/dist/broadcast1.html",
--[[  
    "http://qyz.laohu.com/201611/214387.html",
    "http://qyz.laohu.com/201611/214389.html",
    "http://qyz.laohu.com/201611/214391.html",
--]]  
}
