ResVersionUrlConfig = 
{
["android"]="http://qyzws.autopatch.173.com/qyz/android_version.txt",
["ios"]="http://qyzws.autopatch.173.com/qyz/ios_version.txt",  
}

