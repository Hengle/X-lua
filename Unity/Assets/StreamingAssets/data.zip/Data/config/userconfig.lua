UserConfig = 
{
["DefaultServer"]=
6, 
["DefaultLogin"]=
6, 
}

