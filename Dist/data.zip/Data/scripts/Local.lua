Local = {}
Local.LogManager = true --常规日志开关
Local.LogTraceback = true --日志堆栈信息开关
Local.LogProtocol = false --网络协议日志
Local.Status = false --效率监控开关
Local.HideFPS = true --隐藏FPS
Local.Moduals ={
    Moduals = false, -- 当前加载模块日志
    Skill = false, -- 技能
    Action = false, -- 动作
    UIManager = true, -- UI模块
}

------------------------------------
--常驻内存UI列表
------------------------------------
Local.UIPersistentMap = {
}
