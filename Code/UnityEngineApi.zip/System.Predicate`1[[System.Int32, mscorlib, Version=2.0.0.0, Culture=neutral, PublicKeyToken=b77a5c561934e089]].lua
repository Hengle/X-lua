---@class System.Predicate`1[[System.Int32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]] : System.MulticastDelegate
local m = {}

---@param obj System.Int32
---@return System.Boolean
function m:Invoke(obj)end
---@param obj System.Int32
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(obj,callback,object)end
---@param result System.IAsyncResult
---@return System.Boolean
function m:EndInvoke(result)end
System = {}
System.Predicate`1[[System = {}
System.Predicate`1[[System.Int32, mscorlib, Version=2 = {}
System.Predicate`1[[System.Int32, mscorlib, Version=2.0 = {}
System.Predicate`1[[System.Int32, mscorlib, Version=2.0.0 = {}
System.Predicate`1[[System.Int32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]] = m
return m
