---@field public center UnityEngine.Vector3
---@field public radius System.Single
---@class UnityEngine.SphereCollider : UnityEngine.Collider
local m = {}

UnityEngine = {}
UnityEngine.SphereCollider = m
return m
