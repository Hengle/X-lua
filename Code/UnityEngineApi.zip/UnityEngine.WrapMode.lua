---@class UnityEngine.WrapMode
local m = {}

UnityEngine = {}
UnityEngine.WrapMode = m
return m
