---@field public sharedMesh UnityEngine.Mesh
---@field public convex System.Boolean
---@field public inflateMesh System.Boolean
---@field public cookingOptions UnityEngine.MeshColliderCookingOptions
---@field public skinWidth System.Single
---@field public smoothSphereCollisions System.Boolean
---@class UnityEngine.MeshCollider : UnityEngine.Collider
local m = {}

UnityEngine = {}
UnityEngine.MeshCollider = m
return m
