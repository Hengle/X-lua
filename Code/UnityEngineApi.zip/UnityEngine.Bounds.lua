---@class UnityEngine.Bounds
local m = {}

UnityEngine = {}
UnityEngine.Bounds = m
return m
