---@class UnityEngine.Vector3
local m = {}

UnityEngine = {}
UnityEngine.Vector3 = m
return m
