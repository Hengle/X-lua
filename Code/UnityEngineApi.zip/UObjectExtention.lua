---@class UObjectExtention : System.Object
local m = {}

---@param o UnityEngine.Object
---@return System.Boolean
function m.IsNull(o)end
UObjectExtention = {}
return m
