---@class UnityEngine.Quaternion
local m = {}

UnityEngine = {}
UnityEngine.Quaternion = m
return m
