---@class UnityEngine.Color
local m = {}

UnityEngine = {}
UnityEngine.Color = m
return m
