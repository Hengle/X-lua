---@class UnityEngine.AnimationBlendMode
local m = {}

UnityEngine = {}
UnityEngine.AnimationBlendMode = m
return m
