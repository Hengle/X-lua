---@field public Instance Game.SoundManager
---@class Game.SoundManager : System.Object
local m = {}

---@return System.Void
function m:Init()end
---@return System.Void
function m:Dispose()end
Game = {}
Game.SoundManager = m
return m
