---@class UnityEngine.Ray
local m = {}

UnityEngine = {}
UnityEngine.Ray = m
return m
