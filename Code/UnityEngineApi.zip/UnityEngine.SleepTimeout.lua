---@field public NeverSleep System.Int32
---@field public SystemSetting System.Int32
---@class UnityEngine.SleepTimeout : System.Object
local m = {}

UnityEngine = {}
UnityEngine.SleepTimeout = m
return m
