---@field public center UnityEngine.Vector3
---@field public radius System.Single
---@field public height System.Single
---@field public direction System.Int32
---@class UnityEngine.CapsuleCollider : UnityEngine.Collider
local m = {}

UnityEngine = {}
UnityEngine.CapsuleCollider = m
return m
