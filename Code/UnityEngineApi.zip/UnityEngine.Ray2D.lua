---@class UnityEngine.Ray2D
local m = {}

UnityEngine = {}
UnityEngine.Ray2D = m
return m
