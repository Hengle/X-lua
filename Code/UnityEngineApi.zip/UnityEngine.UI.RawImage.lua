---@field public mainTexture UnityEngine.Texture
---@field public texture UnityEngine.Texture
---@field public uvRect UnityEngine.Rect
---@class UnityEngine.UI.RawImage : UnityEngine.UI.MaskableGraphic
local m = {}

---@return System.Void
function m:SetNativeSize()end
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.RawImage = m
return m
