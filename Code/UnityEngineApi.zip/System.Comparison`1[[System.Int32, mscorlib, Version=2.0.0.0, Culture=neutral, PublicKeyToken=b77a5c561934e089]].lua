---@class System.Comparison`1[[System.Int32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]] : System.MulticastDelegate
local m = {}

---@param x System.Int32
---@param y System.Int32
---@return System.Int32
function m:Invoke(x,y)end
---@param x System.Int32
---@param y System.Int32
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(x,y,callback,object)end
---@param result System.IAsyncResult
---@return System.Int32
function m:EndInvoke(result)end
System = {}
System.Comparison`1[[System = {}
System.Comparison`1[[System.Int32, mscorlib, Version=2 = {}
System.Comparison`1[[System.Int32, mscorlib, Version=2.0 = {}
System.Comparison`1[[System.Int32, mscorlib, Version=2.0.0 = {}
System.Comparison`1[[System.Int32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]] = m
return m
