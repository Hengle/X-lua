---@field public additionalVertexStreams UnityEngine.Mesh
---@field public subMeshStartIndex System.Int32
---@class UnityEngine.MeshRenderer : UnityEngine.Renderer
local m = {}

UnityEngine = {}
UnityEngine.MeshRenderer = m
return m
