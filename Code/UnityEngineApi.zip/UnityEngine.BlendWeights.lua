---@class UnityEngine.BlendWeights
local m = {}

UnityEngine = {}
UnityEngine.BlendWeights = m
return m
