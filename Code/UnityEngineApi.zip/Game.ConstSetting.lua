---@field public FrameRate System.Int32
---@field public Resolution System.Int32
---@field public Blend UnityEngine.BlendWeights
---@field public SleepTime System.Int32
---@field public ResVersionFile System.String
---@field public ResMD5File System.String
---@field public HasDownloadFile System.String
---@field public UrlConfig System.String
---@field public LuaDir System.String
---@field public LuaMain System.String
---@class Game.ConstSetting : System.Object
local m = {}

Game = {}
Game.ConstSetting = m
return m
