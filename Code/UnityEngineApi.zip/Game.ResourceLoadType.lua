---@class Game.ResourceLoadType
local m = {}

Game = {}
Game.ResourceLoadType = m
return m
