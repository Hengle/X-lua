---@class UnityEngine.Space
local m = {}

UnityEngine = {}
UnityEngine.Space = m
return m
