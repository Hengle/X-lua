---@class UnityEngine.CameraClearFlags
local m = {}

UnityEngine = {}
UnityEngine.CameraClearFlags = m
return m
