---@field public moveVector UnityEngine.Vector2
---@field public moveDir UnityEngine.EventSystems.MoveDirection
---@class UnityEngine.EventSystems.AxisEventData : UnityEngine.EventSystems.BaseEventData
local m = {}

UnityEngine = {}
UnityEngine.EventSystems = {}
UnityEngine.EventSystems.AxisEventData = m
return m
