---@class UnityEngine.Mathf
local m = {}

UnityEngine = {}
UnityEngine.Mathf = m
return m
