---@class UnityEngine.LightType
local m = {}

UnityEngine = {}
UnityEngine.LightType = m
return m
