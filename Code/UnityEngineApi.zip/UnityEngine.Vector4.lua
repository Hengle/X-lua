---@class UnityEngine.Vector4
local m = {}

UnityEngine = {}
UnityEngine.Vector4 = m
return m
