---@field public currentInputModule UnityEngine.EventSystems.BaseInputModule
---@field public selectedObject UnityEngine.GameObject
---@class UnityEngine.EventSystems.BaseEventData : UnityEngine.EventSystems.AbstractEventData
local m = {}

UnityEngine = {}
UnityEngine.EventSystems = {}
UnityEngine.EventSystems.BaseEventData = m
return m
