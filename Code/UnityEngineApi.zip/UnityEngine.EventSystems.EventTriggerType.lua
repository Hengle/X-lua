---@class UnityEngine.EventSystems.EventTriggerType
local m = {}

UnityEngine = {}
UnityEngine.EventSystems = {}
UnityEngine.EventSystems.EventTriggerType = m
return m
