---@class UnityEngine.PlayMode
local m = {}

UnityEngine = {}
UnityEngine.PlayMode = m
return m
