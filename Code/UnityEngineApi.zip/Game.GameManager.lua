---@class Game.GameManager : System.Object
local m = {}

---@return System.Void
function m:Init()end
---@return System.Void
function m:Dispose()end
Game = {}
Game.GameManager = m
return m
