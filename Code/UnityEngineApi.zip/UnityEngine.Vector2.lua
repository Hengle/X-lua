---@class UnityEngine.Vector2
local m = {}

UnityEngine = {}
UnityEngine.Vector2 = m
return m
