---@class System.Action`2[[System.Int32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089],[System.Byte[], mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]] : System.MulticastDelegate
local m = {}

---@param arg1 System.Int32
---@param arg2 System.Byte[]
---@return System.Void
function m:Invoke(arg1,arg2)end
---@param arg1 System.Int32
---@param arg2 System.Byte[]
---@param callback System.AsyncCallback
---@param object System.Object
---@return System.IAsyncResult
function m:BeginInvoke(arg1,arg2,callback,object)end
---@param result System.IAsyncResult
---@return System.Void
function m:EndInvoke(result)end
System = {}
System.Action`2[[System = {}
System.Action`2[[System.Int32, mscorlib, Version=2 = {}
System.Action`2[[System.Int32, mscorlib, Version=2.0 = {}
System.Action`2[[System.Int32, mscorlib, Version=2.0.0 = {}
System.Action`2[[System.Int32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089],[System = {}
System.Action`2[[System.Int32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089],[System.Byte[], mscorlib, Version=2 = {}
System.Action`2[[System.Int32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089],[System.Byte[], mscorlib, Version=2.0 = {}
System.Action`2[[System.Int32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089],[System.Byte[], mscorlib, Version=2.0.0 = {}
System.Action`2[[System.Int32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089],[System.Byte[], mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]] = m
return m
