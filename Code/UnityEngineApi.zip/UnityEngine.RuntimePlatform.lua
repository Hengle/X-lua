---@class UnityEngine.RuntimePlatform
local m = {}

UnityEngine = {}
UnityEngine.RuntimePlatform = m
return m
