---@field public enabled System.Boolean
---@field public isActiveAndEnabled System.Boolean
---@class UnityEngine.Behaviour : UnityEngine.Component
local m = {}

UnityEngine = {}
UnityEngine.Behaviour = m
return m
