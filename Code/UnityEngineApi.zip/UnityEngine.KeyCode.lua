---@class UnityEngine.KeyCode
local m = {}

UnityEngine = {}
UnityEngine.KeyCode = m
return m
