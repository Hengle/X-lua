---@class UnityEngine.QueueMode
local m = {}

UnityEngine = {}
UnityEngine.QueueMode = m
return m
