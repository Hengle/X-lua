---@class UnityEngine.Rect
local m = {}

UnityEngine = {}
UnityEngine.Rect = m
return m
