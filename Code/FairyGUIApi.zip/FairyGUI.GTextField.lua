---@field public text System.String
---@field public templateVars System.Collections.Generic.Dictionary`2[[System.String, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089],[System.String, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]
---@field public textFormat FairyGUI.TextFormat
---@field public color UnityEngine.Color
---@field public align FairyGUI.AlignType
---@field public verticalAlign FairyGUI.VertAlignType
---@field public singleLine System.Boolean
---@field public stroke System.Int32
---@field public strokeColor UnityEngine.Color
---@field public shadowOffset UnityEngine.Vector2
---@field public UBBEnabled System.Boolean
---@field public autoSize FairyGUI.AutoSizeType
---@field public textWidth System.Single
---@field public textHeight System.Single
---@class FairyGUI.GTextField : FairyGUI.GObject
local m = {}

---@param name System.String
---@param value System.String
---@return FairyGUI.GTextField
function m:SetVar(name,value)end
---@return System.Void
function m:FlushVars()end
---@param ch System.Char
---@return System.Boolean
function m:HasCharacter(ch)end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_BeforeAdd(buffer,beginPos)end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_AfterAdd(buffer,beginPos)end
FairyGUI = {}
FairyGUI.GTextField = m
return m
