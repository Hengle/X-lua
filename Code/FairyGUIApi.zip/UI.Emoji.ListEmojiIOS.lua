---@field public List_EmojiIOS FairyGUI.GList
---@class UI.Emoji.ListEmojiIOS
local m = {}

UI = {}
UI.Emoji = {}
UI.Emoji.ListEmojiIOS = m
return m
