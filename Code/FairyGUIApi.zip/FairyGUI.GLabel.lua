---@field public icon System.String
---@field public title System.String
---@field public text System.String
---@field public editable System.Boolean
---@field public titleColor UnityEngine.Color
---@field public titleFontSize System.Int32
---@field public color UnityEngine.Color
---@class FairyGUI.GLabel : FairyGUI.GComponent
local m = {}

---@return FairyGUI.GTextField
function m:GetTextField()end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_AfterAdd(buffer,beginPos)end
FairyGUI = {}
FairyGUI.GLabel = m
return m
