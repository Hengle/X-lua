---@field public contentScaleFactor System.Single
---@field public inst FairyGUI.GRoot
---@field public modalLayer FairyGUI.GGraph
---@field public hasModalWindow System.Boolean
---@field public modalWaiting System.Boolean
---@field public touchTarget FairyGUI.GObject
---@field public hasAnyPopup System.Boolean
---@field public focus FairyGUI.GObject
---@field public soundVolume System.Single
---@class FairyGUI.GRoot : FairyGUI.GComponent
local m = {}

---@overload fun(designResolutionX : System.Int32,designResolutionY : System.Int32) : System.Void
---@param designResolutionX System.Int32
---@param designResolutionY System.Int32
---@return System.Void
function m:SetContentScaleFactor(designResolutionX,designResolutionY)end
---@return System.Void
function m:ApplyContentScaleFactor()end
---@param win FairyGUI.Window
---@return System.Void
function m:ShowWindow(win)end
---@param win FairyGUI.Window
---@return System.Void
function m:HideWindow(win)end
---@overload fun(win : FairyGUI.Window) : System.Void
---@param win FairyGUI.Window
---@return System.Void
function m:HideWindowImmediately(win)end
---@param win FairyGUI.Window
---@return System.Void
function m:BringToFront(win)end
---@return System.Void
function m:ShowModalWait()end
---@return System.Void
function m:CloseModalWait()end
---@return System.Void
function m:CloseAllExceptModals()end
---@return System.Void
function m:CloseAllWindows()end
---@return FairyGUI.Window
function m:GetTopWindow()end
---@param obj FairyGUI.DisplayObject
---@return FairyGUI.GObject
function m:DisplayObjectToGObject(obj)end
---@overload fun(popup : FairyGUI.GObject) : System.Void
---@overload fun(popup : FairyGUI.GObject) : System.Void
---@param popup FairyGUI.GObject
---@return System.Void
function m:ShowPopup(popup)end
---@param popup FairyGUI.GObject
---@param target FairyGUI.GObject
---@param downward System.Object
---@return UnityEngine.Vector2
function m:GetPoupPosition(popup,target,downward)end
---@overload fun(popup : FairyGUI.GObject) : System.Void
---@overload fun(popup : FairyGUI.GObject) : System.Void
---@param popup FairyGUI.GObject
---@return System.Void
function m:TogglePopup(popup)end
---@overload fun() : System.Void
---@return System.Void
function m:HidePopup()end
---@param msg System.String
---@return System.Void
function m:ShowTooltips(msg)end
---@param tooltipWin FairyGUI.GObject
---@return System.Void
function m:ShowTooltipsWin(tooltipWin)end
---@return System.Void
function m:HideTooltips()end
---@return System.Void
function m:EnableSound()end
---@return System.Void
function m:DisableSound()end
---@overload fun(clip : UnityEngine.AudioClip,volumeScale : System.Single) : System.Void
---@param clip UnityEngine.AudioClip
---@param volumeScale System.Single
---@return System.Void
function m:PlayOneShotSound(clip,volumeScale)end
FairyGUI = {}
FairyGUI.GRoot = m
return m
