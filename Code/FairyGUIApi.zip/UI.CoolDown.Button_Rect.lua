---@field public Image_maskRect FairyGUI.GImage
---@class UI.CoolDown.Button_Rect
local m = {}

UI = {}
UI.CoolDown = {}
UI.CoolDown.Button_Rect = m
return m
