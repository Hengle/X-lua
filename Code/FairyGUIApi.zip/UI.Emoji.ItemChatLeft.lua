---@field public Loader_icon FairyGUI.GLoader
---@field public RichTextField_LMsg FairyGUI.GRichTextField
---@class UI.Emoji.ItemChatLeft
local m = {}

UI = {}
UI.Emoji = {}
UI.Emoji.ItemChatLeft = m
return m
