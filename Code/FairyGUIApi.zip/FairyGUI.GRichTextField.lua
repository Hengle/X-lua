---@field public richTextField FairyGUI.RichTextField
---@field public emojies System.Collections.Generic.Dictionary`2[[System.UInt32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089],[FairyGUI.Emoji, Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]
---@class FairyGUI.GRichTextField : FairyGUI.GTextField
local m = {}

FairyGUI = {}
FairyGUI.GRichTextField = m
return m
