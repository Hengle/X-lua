---@field public Loader_icon FairyGUI.GLoader
---@field public RichTextField_RMsg FairyGUI.GRichTextField
---@class UI.Emoji.ItemChatRight
local m = {}

UI = {}
UI.Emoji = {}
UI.Emoji.ItemChatRight = m
return m
