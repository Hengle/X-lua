---@field public sound FairyGUI.NAudioClip
---@field public soundVolumeScale System.Single
---@field public changeStateOnClick System.Boolean
---@field public linkedPopup FairyGUI.GObject
---@field public UP System.String
---@field public DOWN System.String
---@field public OVER System.String
---@field public SELECTED_OVER System.String
---@field public DISABLED System.String
---@field public SELECTED_DISABLED System.String
---@field public pageOption FairyGUI.PageOption
---@field public onChanged FairyGUI.EventListener
---@field public icon System.String
---@field public title System.String
---@field public text System.String
---@field public selectedIcon System.String
---@field public selectedTitle System.String
---@field public titleColor UnityEngine.Color
---@field public color UnityEngine.Color
---@field public titleFontSize System.Int32
---@field public selected System.Boolean
---@field public mode FairyGUI.ButtonMode
---@field public relatedController FairyGUI.Controller
---@class FairyGUI.GButton : FairyGUI.GComponent
local m = {}

---@param downEffect System.Boolean
---@return System.Void
function m:FireClick(downEffect)end
---@return FairyGUI.GTextField
function m:GetTextField()end
---@param c FairyGUI.Controller
---@return System.Void
function m:HandleControllerChanged(c)end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_AfterAdd(buffer,beginPos)end
FairyGUI = {}
FairyGUI.GButton = m
return m
