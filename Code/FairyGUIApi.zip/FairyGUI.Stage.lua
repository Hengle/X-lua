---@field public stageHeight System.Int32
---@field public stageWidth System.Int32
---@field public soundVolume System.Single
---@field public onStageResized FairyGUI.EventListener
---@field public inst FairyGUI.Stage
---@field public touchScreen System.Boolean
---@field public keyboardInput System.Boolean
---@field public isTouchOnUI System.Boolean
---@field public touchTarget FairyGUI.DisplayObject
---@field public focus FairyGUI.DisplayObject
---@field public touchPosition UnityEngine.Vector2
---@field public touchCount System.Int32
---@field public keyboard FairyGUI.IKeyboard
---@class FairyGUI.Stage : FairyGUI.Container
local m = {}

---@return System.Void
function m.Instantiate()end
---@return System.Void
function m:Dispose()end
---@param touchId System.Int32
---@return UnityEngine.Vector2
function m:GetTouchPosition(touchId)end
---@param result System.Int32[]
---@return System.Int32[]
function m:GetAllTouch(result)end
---@return System.Void
function m:ResetInputState()end
---@param touchId System.Int32
---@return System.Void
function m:CancelClick(touchId)end
---@return System.Void
function m:EnableSound()end
---@return System.Void
function m:DisableSound()end
---@overload fun(clip : UnityEngine.AudioClip,volumeScale : System.Single) : System.Void
---@param clip UnityEngine.AudioClip
---@param volumeScale System.Single
---@return System.Void
function m:PlayOneShotSound(clip,volumeScale)end
---@param text System.String
---@param autocorrection System.Boolean
---@param multiline System.Boolean
---@param secure System.Boolean
---@param alert System.Boolean
---@param textPlaceholder System.String
---@param keyboardType System.Int32
---@param hideInput System.Boolean
---@return System.Void
function m:OpenKeyboard(text,autocorrection,multiline,secure,alert,textPlaceholder,keyboardType,hideInput)end
---@return System.Void
function m:CloseKeyboard()end
---@param value System.String
---@return System.Void
function m:InputString(value)end
---@overload fun(screenPos : UnityEngine.Vector2,buttonDown : System.Boolean) : System.Void
---@overload fun(screenPos : UnityEngine.Vector2,buttonDown : System.Boolean) : System.Void
---@overload fun(screenPos : UnityEngine.Vector2,buttonDown : System.Boolean) : System.Void
---@param screenPos UnityEngine.Vector2
---@param buttonDown System.Boolean
---@return System.Void
function m:SetCustomInput(screenPos,buttonDown)end
---@param target FairyGUI.Container
---@return System.Void
function m:ApplyPanelOrder(target)end
---@param panelSortingOrder System.Int32
---@return System.Void
function m:SortWorldSpacePanelsByZOrder(panelSortingOrder)end
---@param texture FairyGUI.NTexture
---@return System.Void
function m:MonitorTexture(texture)end
---@param touchId System.Int32
---@param target FairyGUI.EventDispatcher
---@return System.Void
function m:AddTouchMonitor(touchId,target)end
---@param target FairyGUI.EventDispatcher
---@return System.Void
function m:RemoveTouchMonitor(target)end
FairyGUI = {}
FairyGUI.Stage = m
return m
