---@field public itemCount System.Int32
---@field public contentPane FairyGUI.GComponent
---@field public list FairyGUI.GList
---@class FairyGUI.PopupMenu : System.Object
local m = {}

---@overload fun(caption : System.String,callback : FairyGUI.EventCallback0) : FairyGUI.GButton
---@param caption System.String
---@param callback FairyGUI.EventCallback0
---@return FairyGUI.GButton
function m:AddItem(caption,callback)end
---@overload fun(caption : System.String,index : System.Int32,callback : FairyGUI.EventCallback0) : FairyGUI.GButton
---@param caption System.String
---@param index System.Int32
---@param callback FairyGUI.EventCallback0
---@return FairyGUI.GButton
function m:AddItemAt(caption,index,callback)end
---@return System.Void
function m:AddSeperator()end
---@param index System.Int32
---@return System.String
function m:GetItemName(index)end
---@param name System.String
---@param caption System.String
---@return System.Void
function m:SetItemText(name,caption)end
---@param name System.String
---@param visible System.Boolean
---@return System.Void
function m:SetItemVisible(name,visible)end
---@param name System.String
---@param grayed System.Boolean
---@return System.Void
function m:SetItemGrayed(name,grayed)end
---@param name System.String
---@param checkable System.Boolean
---@return System.Void
function m:SetItemCheckable(name,checkable)end
---@param name System.String
---@param check System.Boolean
---@return System.Void
function m:SetItemChecked(name,check)end
---@param name System.String
---@return System.Boolean
function m:isItemChecked(name)end
---@param name System.String
---@return System.Boolean
function m:RemoveItem(name)end
---@return System.Void
function m:ClearItems()end
---@return System.Void
function m:Dispose()end
---@overload fun() : System.Void
---@return System.Void
function m:Show()end
FairyGUI = {}
FairyGUI.PopupMenu = m
return m
