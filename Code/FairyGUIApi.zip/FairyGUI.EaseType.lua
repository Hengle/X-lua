---@class FairyGUI.EaseType
local m = {}

FairyGUI = {}
FairyGUI.EaseType = m
return m
