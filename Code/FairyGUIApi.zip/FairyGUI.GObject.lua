---@field public name System.String
---@field public data System.Object
---@field public sourceWidth System.Int32
---@field public sourceHeight System.Int32
---@field public initWidth System.Int32
---@field public initHeight System.Int32
---@field public minWidth System.Int32
---@field public maxWidth System.Int32
---@field public minHeight System.Int32
---@field public maxHeight System.Int32
---@field public dragBounds System.Nullable`1[[UnityEngine.Rect, UnityEngine.CoreModule, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]
---@field public packageItem FairyGUI.PackageItem
---@field public id System.String
---@field public relations FairyGUI.Relations
---@field public parent FairyGUI.GComponent
---@field public displayObject FairyGUI.DisplayObject
---@field public onClick FairyGUI.EventListener
---@field public onRightClick FairyGUI.EventListener
---@field public onTouchBegin FairyGUI.EventListener
---@field public onTouchMove FairyGUI.EventListener
---@field public onTouchEnd FairyGUI.EventListener
---@field public onRollOver FairyGUI.EventListener
---@field public onRollOut FairyGUI.EventListener
---@field public onAddedToStage FairyGUI.EventListener
---@field public onRemovedFromStage FairyGUI.EventListener
---@field public onKeyDown FairyGUI.EventListener
---@field public onClickLink FairyGUI.EventListener
---@field public onPositionChanged FairyGUI.EventListener
---@field public onSizeChanged FairyGUI.EventListener
---@field public onDragStart FairyGUI.EventListener
---@field public onDragMove FairyGUI.EventListener
---@field public onDragEnd FairyGUI.EventListener
---@field public OnGearStop FairyGUI.EventListener
---@field public draggingObject FairyGUI.GObject
---@field public x System.Single
---@field public y System.Single
---@field public z System.Single
---@field public xy UnityEngine.Vector2
---@field public position UnityEngine.Vector3
---@field public pixelSnapping System.Boolean
---@field public width System.Single
---@field public height System.Single
---@field public size UnityEngine.Vector2
---@field public actualWidth System.Single
---@field public actualHeight System.Single
---@field public xMin System.Single
---@field public yMin System.Single
---@field public scaleX System.Single
---@field public scaleY System.Single
---@field public scale UnityEngine.Vector2
---@field public skew UnityEngine.Vector2
---@field public pivotX System.Single
---@field public pivotY System.Single
---@field public pivot UnityEngine.Vector2
---@field public pivotAsAnchor System.Boolean
---@field public touchable System.Boolean
---@field public grayed System.Boolean
---@field public enabled System.Boolean
---@field public rotation System.Single
---@field public rotationX System.Single
---@field public rotationY System.Single
---@field public alpha System.Single
---@field public visible System.Boolean
---@field public sortingOrder System.Int32
---@field public focusable System.Boolean
---@field public focused System.Boolean
---@field public tooltips System.String
---@field public filter FairyGUI.IFilter
---@field public blendMode FairyGUI.BlendMode
---@field public gameObjectName System.String
---@field public inContainer System.Boolean
---@field public onStage System.Boolean
---@field public resourceURL System.String
---@field public gearXY FairyGUI.GearXY
---@field public gearSize FairyGUI.GearSize
---@field public gearLook FairyGUI.GearLook
---@field public group FairyGUI.GGroup
---@field public root FairyGUI.GRoot
---@field public text System.String
---@field public icon System.String
---@field public draggable System.Boolean
---@field public dragging System.Boolean
---@field public isDisposed System.Boolean
---@field public asImage FairyGUI.GImage
---@field public asCom FairyGUI.GComponent
---@field public asButton FairyGUI.GButton
---@field public asLabel FairyGUI.GLabel
---@field public asProgress FairyGUI.GProgressBar
---@field public asSlider FairyGUI.GSlider
---@field public asComboBox FairyGUI.GComboBox
---@field public asTextField FairyGUI.GTextField
---@field public asRichTextField FairyGUI.GRichTextField
---@field public asTextInput FairyGUI.GTextInput
---@field public asLoader FairyGUI.GLoader
---@field public asList FairyGUI.GList
---@field public asGraph FairyGUI.GGraph
---@field public asGroup FairyGUI.GGroup
---@field public asMovieClip FairyGUI.GMovieClip
---@class FairyGUI.GObject : FairyGUI.EventDispatcher
local m = {}

---@overload fun(xv : System.Single,yv : System.Single) : System.Void
---@param xv System.Single
---@param yv System.Single
---@return System.Void
function m:SetXY(xv,yv)end
---@param xv System.Single
---@param yv System.Single
---@param zv System.Single
---@return System.Void
function m:SetPosition(xv,yv,zv)end
---@overload fun() : System.Void
---@return System.Void
function m:Center()end
---@return System.Void
function m:MakeFullScreen()end
---@overload fun(wv : System.Single,hv : System.Single) : System.Void
---@param wv System.Single
---@param hv System.Single
---@return System.Void
function m:SetSize(wv,hv)end
---@param wv System.Single
---@param hv System.Single
---@return System.Void
function m:SetScale(wv,hv)end
---@overload fun(xv : System.Single,yv : System.Single) : System.Void
---@param xv System.Single
---@param yv System.Single
---@return System.Void
function m:SetPivot(xv,yv)end
---@return System.Void
function m:RequestFocus()end
---@param obj FairyGUI.GObject
---@return System.Void
function m:SetHome(obj)end
---@param index System.Int32
---@return FairyGUI.GearBase
function m:GetGear(index)end
---@return System.Void
function m:InvalidateBatchingState()end
---@param c FairyGUI.Controller
---@return System.Void
function m:HandleControllerChanged(c)end
---@overload fun(target : FairyGUI.GObject,relationType : FairyGUI.RelationType) : System.Void
---@param target FairyGUI.GObject
---@param relationType FairyGUI.RelationType
---@return System.Void
function m:AddRelation(target,relationType)end
---@param target FairyGUI.GObject
---@param relationType FairyGUI.RelationType
---@return System.Void
function m:RemoveRelation(target,relationType)end
---@return System.Void
function m:RemoveFromParent()end
---@overload fun() : System.Void
---@return System.Void
function m:StartDrag()end
---@return System.Void
function m:StopDrag()end
---@overload fun(pt : UnityEngine.Vector2) : UnityEngine.Vector2
---@param pt UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:LocalToGlobal(pt)end
---@overload fun(pt : UnityEngine.Vector2) : UnityEngine.Vector2
---@param pt UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:GlobalToLocal(pt)end
---@param pt UnityEngine.Vector2
---@param r FairyGUI.GRoot
---@return UnityEngine.Vector2
function m:LocalToRoot(pt,r)end
---@param pt UnityEngine.Vector2
---@param r FairyGUI.GRoot
---@return UnityEngine.Vector2
function m:RootToLocal(pt,r)end
---@overload fun(pt : UnityEngine.Vector3) : UnityEngine.Vector2
---@param pt UnityEngine.Vector3
---@return UnityEngine.Vector2
function m:WorldToLocal(pt)end
---@param pt UnityEngine.Vector2
---@param targetSpace FairyGUI.GObject
---@return UnityEngine.Vector2
function m:TransformPoint(pt,targetSpace)end
---@param rect UnityEngine.Rect
---@param targetSpace FairyGUI.GObject
---@return UnityEngine.Rect
function m:TransformRect(rect,targetSpace)end
---@return System.Void
function m:Dispose()end
---@return System.Void
function m:ConstructFromResource()end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_BeforeAdd(buffer,beginPos)end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_AfterAdd(buffer,beginPos)end
---@param endValue UnityEngine.Vector2
---@param duration System.Single
---@return FairyGUI.GTweener
function m:TweenMove(endValue,duration)end
---@param endValue System.Single
---@param duration System.Single
---@return FairyGUI.GTweener
function m:TweenMoveX(endValue,duration)end
---@param endValue System.Single
---@param duration System.Single
---@return FairyGUI.GTweener
function m:TweenMoveY(endValue,duration)end
---@param endValue UnityEngine.Vector2
---@param duration System.Single
---@return FairyGUI.GTweener
function m:TweenScale(endValue,duration)end
---@param endValue System.Single
---@param duration System.Single
---@return FairyGUI.GTweener
function m:TweenScaleX(endValue,duration)end
---@param endValue System.Single
---@param duration System.Single
---@return FairyGUI.GTweener
function m:TweenScaleY(endValue,duration)end
---@param endValue UnityEngine.Vector2
---@param duration System.Single
---@return FairyGUI.GTweener
function m:TweenResize(endValue,duration)end
---@param endValue System.Single
---@param duration System.Single
---@return FairyGUI.GTweener
function m:TweenFade(endValue,duration)end
---@param endValue System.Single
---@param duration System.Single
---@return FairyGUI.GTweener
function m:TweenRotate(endValue,duration)end
FairyGUI = {}
FairyGUI.GObject = m
return m
