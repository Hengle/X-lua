---@field public onPlayEnd FairyGUI.EventListener
---@field public playing System.Boolean
---@field public frame System.Int32
---@field public color UnityEngine.Color
---@field public flip FairyGUI.FlipType
---@field public material UnityEngine.Material
---@field public shader System.String
---@field public timeScale System.Single
---@field public ignoreEngineTimeScale System.Boolean
---@class FairyGUI.GMovieClip : FairyGUI.GObject
local m = {}

---@return System.Void
function m:Rewind()end
---@param anotherMc FairyGUI.GMovieClip
---@return System.Void
function m:SyncStatus(anotherMc)end
---@param time System.Single
---@return System.Void
function m:Advance(time)end
---@param start System.Int32
---@param end System.Int32
---@param times System.Int32
---@param endAt System.Int32
---@return System.Void
function m:SetPlaySettings(start,end,times,endAt)end
---@return System.Void
function m:ConstructFromResource()end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_BeforeAdd(buffer,beginPos)end
FairyGUI = {}
FairyGUI.GMovieClip = m
return m
