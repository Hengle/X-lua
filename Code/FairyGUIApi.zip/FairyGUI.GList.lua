---@field public defaultItem System.String
---@field public foldInvisibleItems System.Boolean
---@field public selectionMode FairyGUI.ListSelectionMode
---@field public itemRenderer FairyGUI.ListItemRenderer
---@field public itemProvider FairyGUI.ListItemProvider
---@field public scrollItemToViewOnClick System.Boolean
---@field public onClickItem FairyGUI.EventListener
---@field public onRightClickItem FairyGUI.EventListener
---@field public layout FairyGUI.ListLayoutType
---@field public lineCount System.Int32
---@field public columnCount System.Int32
---@field public lineGap System.Int32
---@field public columnGap System.Int32
---@field public align FairyGUI.AlignType
---@field public verticalAlign FairyGUI.VertAlignType
---@field public autoResizeItem System.Boolean
---@field public itemPool FairyGUI.GObjectPool
---@field public selectedIndex System.Int32
---@field public selectionController FairyGUI.Controller
---@field public touchItem FairyGUI.GObject
---@field public isVirtual System.Boolean
---@field public numItems System.Int32
---@class FairyGUI.GList : FairyGUI.GComponent
local m = {}

---@return System.Void
function m:Dispose()end
---@param url System.String
---@return FairyGUI.GObject
function m:GetFromPool(url)end
---@overload fun() : FairyGUI.GObject
---@return FairyGUI.GObject
function m:AddItemFromPool()end
---@param child FairyGUI.GObject
---@param index System.Int32
---@return FairyGUI.GObject
function m:AddChildAt(child,index)end
---@param index System.Int32
---@param dispose System.Boolean
---@return FairyGUI.GObject
function m:RemoveChildAt(index,dispose)end
---@param index System.Int32
---@return System.Void
function m:RemoveChildToPoolAt(index)end
---@param child FairyGUI.GObject
---@return System.Void
function m:RemoveChildToPool(child)end
---@overload fun() : System.Void
---@return System.Void
function m:RemoveChildrenToPool()end
---@return System.Collections.Generic.List`1[[System.Int32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]
function m:GetSelection()end
---@param index System.Int32
---@param scrollItToView System.Boolean
---@return System.Void
function m:AddSelection(index,scrollItToView)end
---@param index System.Int32
---@return System.Void
function m:RemoveSelection(index)end
---@return System.Void
function m:ClearSelection()end
---@return System.Void
function m:SelectAll()end
---@return System.Void
function m:SelectNone()end
---@return System.Void
function m:SelectReverse()end
---@param dir System.Int32
---@return System.Void
function m:HandleArrowKey(dir)end
---@overload fun(itemCount : System.Int32) : System.Void
---@param itemCount System.Int32
---@return System.Void
function m:ResizeToFit(itemCount)end
---@param c FairyGUI.Controller
---@return System.Void
function m:HandleControllerChanged(c)end
---@overload fun(index : System.Int32) : System.Void
---@overload fun(index : System.Int32) : System.Void
---@param index System.Int32
---@return System.Void
function m:ScrollToView(index)end
---@return System.Int32
function m:GetFirstChildInView()end
---@param index System.Int32
---@return System.Int32
function m:ChildIndexToItemIndex(index)end
---@param index System.Int32
---@return System.Int32
function m:ItemIndexToChildIndex(index)end
---@return System.Void
function m:SetVirtual()end
---@return System.Void
function m:SetVirtualAndLoop()end
---@return System.Void
function m:RefreshVirtualList()end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_BeforeAdd(buffer,beginPos)end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_AfterAdd(buffer,beginPos)end
FairyGUI = {}
FairyGUI.GList = m
return m
