---@field public size System.Int32
---@field public font System.String
---@field public color UnityEngine.Color
---@field public lineSpacing System.Int32
---@field public letterSpacing System.Int32
---@field public bold System.Boolean
---@field public underline System.Boolean
---@field public italic System.Boolean
---@field public gradientColor UnityEngine.Color32[]
---@field public align FairyGUI.AlignType
---@field public specialStyle FairyGUI.TextFormat+SpecialStyle
---@class FairyGUI.TextFormat : System.Object
local m = {}

---@param value System.UInt32
---@return System.Void
function m:SetColor(value)end
---@param aFormat FairyGUI.TextFormat
---@return System.Boolean
function m:EqualStyle(aFormat)end
---@param source FairyGUI.TextFormat
---@return System.Void
function m:CopyFrom(source)end
FairyGUI = {}
FairyGUI.TextFormat = m
return m
