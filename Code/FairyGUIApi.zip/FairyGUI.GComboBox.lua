---@field public visibleItemCount System.Int32
---@field public dropdown FairyGUI.GComponent
---@field public onChanged FairyGUI.EventListener
---@field public icon System.String
---@field public title System.String
---@field public text System.String
---@field public titleColor UnityEngine.Color
---@field public titleFontSize System.Int32
---@field public items System.String[]
---@field public icons System.String[]
---@field public values System.String[]
---@field public selectedIndex System.Int32
---@field public selectionController FairyGUI.Controller
---@field public value System.String
---@field public popupDirection FairyGUI.PopupDirection
---@class FairyGUI.GComboBox : FairyGUI.GComponent
local m = {}

---@return FairyGUI.GTextField
function m:GetTextField()end
---@param c FairyGUI.Controller
---@return System.Void
function m:HandleControllerChanged(c)end
---@return System.Void
function m:Dispose()end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_AfterAdd(buffer,beginPos)end
---@return System.Void
function m:UpdateDropdownList()end
FairyGUI = {}
FairyGUI.GComboBox = m
return m
