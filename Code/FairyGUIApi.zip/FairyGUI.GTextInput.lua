---@field public onFocusIn FairyGUI.EventListener
---@field public onFocusOut FairyGUI.EventListener
---@field public onChanged FairyGUI.EventListener
---@field public onSubmit FairyGUI.EventListener
---@field public inputTextField FairyGUI.InputTextField
---@field public editable System.Boolean
---@field public hideInput System.Boolean
---@field public maxLength System.Int32
---@field public restrict System.String
---@field public displayAsPassword System.Boolean
---@field public caretPosition System.Int32
---@field public promptText System.String
---@field public keyboardInput System.Boolean
---@field public keyboardType System.Int32
---@field public emojies System.Collections.Generic.Dictionary`2[[System.UInt32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089],[FairyGUI.Emoji, Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]
---@class FairyGUI.GTextInput : FairyGUI.GTextField
local m = {}

---@param start System.Int32
---@param length System.Int32
---@return System.Void
function m:SetSelection(start,length)end
---@param value System.String
---@return System.Void
function m:ReplaceSelection(value)end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_BeforeAdd(buffer,beginPos)end
FairyGUI = {}
FairyGUI.GTextInput = m
return m
