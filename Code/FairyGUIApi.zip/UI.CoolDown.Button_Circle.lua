---@field public TextField_CoolTime FairyGUI.GTextField
---@field public Image_maskCircle FairyGUI.GImage
---@class UI.CoolDown.Button_Circle
local m = {}

UI = {}
UI.CoolDown = {}
UI.CoolDown.Button_Circle = m
return m
