---@field public defaultFont System.String
---@field public renderingTextBrighterOnDesktop System.Boolean
---@field public windowModalWaiting System.String
---@field public globalModalWaiting System.String
---@field public modalLayerColor UnityEngine.Color
---@field public buttonSound FairyGUI.NAudioClip
---@field public buttonSoundVolumeScale System.Single
---@field public horizontalScrollBar System.String
---@field public verticalScrollBar System.String
---@field public defaultScrollStep System.Single
---@field public defaultScrollDecelerationRate System.Single
---@field public defaultScrollBarDisplay FairyGUI.ScrollBarDisplayType
---@field public defaultScrollTouchEffect System.Boolean
---@field public defaultScrollBounceEffect System.Boolean
---@field public popupMenu System.String
---@field public popupMenu_seperator System.String
---@field public loaderErrorSign System.String
---@field public tooltipsWin System.String
---@field public defaultComboBoxVisibleItemCount System.Int32
---@field public touchScrollSensitivity System.Int32
---@field public touchDragSensitivity System.Int32
---@field public clickDragSensitivity System.Int32
---@field public allowSoftnessOnTopOrLeftSide System.Boolean
---@field public bringWindowToFrontOnClick System.Boolean
---@field public inputCaretSize System.Int32
---@field public inputHighlightColor UnityEngine.Color
---@field public frameTimeForAsyncUIConstruction System.Single
---@field public depthSupportForPaintingMode System.Boolean
---@field public enhancedTextOutlineEffect System.Boolean
---@field public Items System.Collections.Generic.List`1[[FairyGUI.UIConfig+ConfigValue, Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]
---@field public PreloadPackages System.Collections.Generic.List`1[[System.String, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]
---@field public soundLoader FairyGUI.UIConfig+SoundLoader
---@class FairyGUI.UIConfig : UnityEngine.MonoBehaviour
local m = {}

---@return System.Void
function m:Load()end
---@return System.Void
function m.ClearResourceRefs()end
---@return System.Void
function m:ApplyModifiedProperties()end
FairyGUI = {}
FairyGUI.UIConfig = m
return m
