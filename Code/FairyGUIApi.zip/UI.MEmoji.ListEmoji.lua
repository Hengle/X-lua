---@field public List_Emoji FairyGUI.GList
---@class UI.MEmoji.ListEmoji
local m = {}

UI = {}
UI.MEmoji = {}
UI.MEmoji.ListEmoji = m
return m
