---@field public URL_PREFIX System.String
---@field public id System.String
---@field public name System.String
---@field public assetPath System.String
---@field public customId System.String
---@field public resBundle UnityEngine.AssetBundle
---@class FairyGUI.UIPackage : System.Object
local m = {}

---@param id System.String
---@return FairyGUI.UIPackage
function m.GetById(id)end
---@param name System.String
---@return FairyGUI.UIPackage
function m.GetByName(name)end
---@overload fun(bundle : UnityEngine.AssetBundle) : FairyGUI.UIPackage
---@overload fun(bundle : UnityEngine.AssetBundle) : FairyGUI.UIPackage
---@overload fun(bundle : UnityEngine.AssetBundle) : FairyGUI.UIPackage
---@overload fun(bundle : UnityEngine.AssetBundle) : FairyGUI.UIPackage
---@overload fun(bundle : UnityEngine.AssetBundle) : FairyGUI.UIPackage
---@param bundle UnityEngine.AssetBundle
---@return FairyGUI.UIPackage
function m.AddPackage(bundle)end
---@param packageIdOrName System.String
---@return System.Void
function m.RemovePackage(packageIdOrName)end
---@return System.Void
function m.RemoveAllPackages()end
---@return System.Collections.Generic.List`1[[FairyGUI.UIPackage, Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]
function m.GetPackages()end
---@overload fun(pkgName : System.String,resName : System.String) : FairyGUI.GObject
---@overload fun(pkgName : System.String,resName : System.String) : FairyGUI.GObject
---@overload fun(pkgName : System.String,resName : System.String) : FairyGUI.GObject
---@param pkgName System.String
---@param resName System.String
---@return FairyGUI.GObject
function m.CreateObject(pkgName,resName)end
---@overload fun(url : System.String) : FairyGUI.GObject
---@overload fun(url : System.String) : FairyGUI.GObject
---@param url System.String
---@return FairyGUI.GObject
function m.CreateObjectFromURL(url)end
---@overload fun(pkgName : System.String,resName : System.String,callback : FairyGUI.UIPackage+CreateObjectCallback) : System.Void
---@param pkgName System.String
---@param resName System.String
---@param callback FairyGUI.UIPackage+CreateObjectCallback
---@return System.Void
function m.CreateObjectAsync(pkgName,resName,callback)end
---@overload fun(pkgName : System.String,resName : System.String) : System.Object
---@overload fun(pkgName : System.String,resName : System.String) : System.Object
---@param pkgName System.String
---@param resName System.String
---@return System.Object
function m.GetItemAsset(pkgName,resName)end
---@param url System.String
---@return System.Object
function m.GetItemAssetByURL(url)end
---@param pkgName System.String
---@param resName System.String
---@return System.String
function m.GetItemURL(pkgName,resName)end
---@param url System.String
---@return FairyGUI.PackageItem
function m.GetItemByURL(url)end
---@param url System.String
---@return System.String
function m.NormalizeURL(url)end
---@param source FairyGUI.Utils.XML
---@return System.Void
function m.SetStringsSource(source)end
---@return System.Void
function m:LoadAllAssets()end
---@return System.Void
function m:UnloadAssets()end
---@overload fun() : System.Void
---@return System.Void
function m:ReloadAssets()end
---@return System.Collections.Generic.List`1[[FairyGUI.PackageItem, Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]
function m:GetItems()end
---@param itemId System.String
---@return FairyGUI.PackageItem
function m:GetItem(itemId)end
---@param itemName System.String
---@return FairyGUI.PackageItem
function m:GetItemByName(itemName)end
FairyGUI = {}
FairyGUI.UIPackage = m
return m
