---@field public color UnityEngine.Color
---@field public shape FairyGUI.Shape
---@class FairyGUI.GGraph : FairyGUI.GObject
local m = {}

---@param target FairyGUI.GObject
---@return System.Void
function m:ReplaceMe(target)end
---@param target FairyGUI.GObject
---@return System.Void
function m:AddBeforeMe(target)end
---@param target FairyGUI.GObject
---@return System.Void
function m:AddAfterMe(target)end
---@param obj FairyGUI.DisplayObject
---@return System.Void
function m:SetNativeObject(obj)end
---@param aWidth System.Single
---@param aHeight System.Single
---@param lineSize System.Int32
---@param lineColor UnityEngine.Color
---@param fillColor UnityEngine.Color
---@return System.Void
function m:DrawRect(aWidth,aHeight,lineSize,lineColor,fillColor)end
---@param aWidth System.Single
---@param aHeight System.Single
---@param fillColor UnityEngine.Color
---@param corner System.Single[]
---@return System.Void
function m:DrawRoundRect(aWidth,aHeight,fillColor,corner)end
---@param aWidth System.Single
---@param aHeight System.Single
---@param fillColor UnityEngine.Color
---@return System.Void
function m:DrawEllipse(aWidth,aHeight,fillColor)end
---@param aWidth System.Single
---@param aHeight System.Single
---@param points UnityEngine.Vector2[]
---@param fillColor UnityEngine.Color
---@return System.Void
function m:DrawPolygon(aWidth,aHeight,points,fillColor)end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_BeforeAdd(buffer,beginPos)end
FairyGUI = {}
FairyGUI.GGraph = m
return m
