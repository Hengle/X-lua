---@field public name System.String
---@field public onChanged FairyGUI.EventListener
---@field public selectedIndex System.Int32
---@field public selectedPage System.String
---@field public previsousIndex System.Int32
---@field public previousPage System.String
---@field public pageCount System.Int32
---@class FairyGUI.Controller : FairyGUI.EventDispatcher
local m = {}

---@return System.Void
function m:Dispose()end
---@param value System.Int32
---@return System.Void
function m:SetSelectedIndex(value)end
---@param value System.String
---@return System.Void
function m:SetSelectedPage(value)end
---@param index System.Int32
---@return System.String
function m:GetPageName(index)end
---@param aName System.String
---@return System.String
function m:GetPageIdByName(aName)end
---@param name System.String
---@return System.Void
function m:AddPage(name)end
---@param name System.String
---@param index System.Int32
---@return System.Void
function m:AddPageAt(name,index)end
---@param name System.String
---@return System.Void
function m:RemovePage(name)end
---@param index System.Int32
---@return System.Void
function m:RemovePageAt(index)end
---@return System.Void
function m:ClearPages()end
---@param aName System.String
---@return System.Boolean
function m:HasPage(aName)end
---@return System.Void
function m:RunActions()end
---@param buffer FairyGUI.Utils.ByteBuffer
---@return System.Void
function m:Setup(buffer)end
FairyGUI = {}
FairyGUI.Controller = m
return m
