---@field public color UnityEngine.Color
---@field public flip FairyGUI.FlipType
---@field public fillMethod FairyGUI.FillMethod
---@field public fillOrigin System.Int32
---@field public fillClockwise System.Boolean
---@field public fillAmount System.Single
---@field public texture FairyGUI.NTexture
---@field public material UnityEngine.Material
---@field public shader System.String
---@class FairyGUI.GImage : FairyGUI.GObject
local m = {}

---@return System.Void
function m:ConstructFromResource()end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_BeforeAdd(buffer,beginPos)end
FairyGUI = {}
FairyGUI.GImage = m
return m
