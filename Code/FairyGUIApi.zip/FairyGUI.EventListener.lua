---@field public owner FairyGUI.EventDispatcher
---@field public type System.String
---@field public isEmpty System.Boolean
---@field public isDispatching System.Boolean
---@class FairyGUI.EventListener : System.Object
local m = {}

---@param callback FairyGUI.EventCallback1
---@return System.Void
function m:AddCapture(callback)end
---@param callback FairyGUI.EventCallback1
---@return System.Void
function m:RemoveCapture(callback)end
---@overload fun(callback : FairyGUI.EventCallback1) : System.Void
---@param callback FairyGUI.EventCallback1
---@return System.Void
function m:Add(callback)end
---@overload fun(callback : FairyGUI.EventCallback1) : System.Void
---@param callback FairyGUI.EventCallback1
---@return System.Void
function m:Remove(callback)end
---@overload fun(callback : FairyGUI.EventCallback1) : System.Void
---@param callback FairyGUI.EventCallback1
---@return System.Void
function m:Set(callback)end
---@return System.Void
function m:Clear()end
---@overload fun() : System.Boolean
---@return System.Boolean
function m:Call()end
---@overload fun(data : System.Object) : System.Boolean
---@param data System.Object
---@return System.Boolean
function m:BubbleCall(data)end
---@overload fun(data : System.Object) : System.Boolean
---@param data System.Object
---@return System.Boolean
function m:BroadcastCall(data)end
FairyGUI = {}
FairyGUI.EventListener = m
return m
