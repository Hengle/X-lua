---@field public bringToFontOnClick System.Boolean
---@field public contentPane FairyGUI.GComponent
---@field public frame FairyGUI.GComponent
---@field public closeButton FairyGUI.GObject
---@field public dragArea FairyGUI.GObject
---@field public contentArea FairyGUI.GObject
---@field public modalWaitingPane FairyGUI.GObject
---@field public isShowing System.Boolean
---@field public isTop System.Boolean
---@field public modal System.Boolean
---@field public modalWaiting System.Boolean
---@class FairyGUI.Window : FairyGUI.GComponent
local m = {}

---@param source FairyGUI.IUISource
---@return System.Void
function m:AddUISource(source)end
---@return System.Void
function m:Show()end
---@param r FairyGUI.GRoot
---@return System.Void
function m:ShowOn(r)end
---@return System.Void
function m:Hide()end
---@return System.Void
function m:HideImmediately()end
---@param r FairyGUI.GRoot
---@param restraint System.Boolean
---@return System.Void
function m:CenterOn(r,restraint)end
---@return System.Void
function m:ToggleStatus()end
---@return System.Void
function m:BringToFront()end
---@overload fun() : System.Void
---@return System.Void
function m:ShowModalWait()end
---@overload fun() : System.Boolean
---@return System.Boolean
function m:CloseModalWait()end
---@return System.Void
function m:Init()end
---@return System.Void
function m:Dispose()end
FairyGUI = {}
FairyGUI.Window = m
return m
