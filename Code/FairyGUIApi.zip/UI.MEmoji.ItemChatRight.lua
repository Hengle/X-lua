---@field public Loader_icon MyLoader
---@field public RichTextField_RMsg FairyGUI.GRichTextField
---@class UI.MEmoji.ItemChatRight
local m = {}

UI = {}
UI.MEmoji = {}
UI.MEmoji.ItemChatRight = m
return m
