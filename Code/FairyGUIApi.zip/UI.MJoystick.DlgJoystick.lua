---@field public Image_Center FairyGUI.GImage
---@field public Button_Joystick FairyGUI.GButton
---@field public Graph_Area FairyGUI.GGraph
---@field public TextField_Degree FairyGUI.GTextField
---@class UI.MJoystick.DlgJoystick
local m = {}

UI = {}
UI.MJoystick = {}
UI.MJoystick.DlgJoystick = m
return m
