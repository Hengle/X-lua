---@field public Button_Bag FairyGUI.GButton
---@field public Button_Start FairyGUI.GButton
---@class UI.Guide.DlgNormalTest
local m = {}

UI = {}
UI.Guide = {}
UI.Guide.DlgNormalTest = m
return m
