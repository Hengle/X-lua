---@field public x System.Single
---@field public y System.Single
---@field public z System.Single
---@field public w System.Single
---@field public d System.Double
---@field public vec2 UnityEngine.Vector2
---@field public vec3 UnityEngine.Vector3
---@field public vec4 UnityEngine.Vector4
---@field public color UnityEngine.Color
---@field public Item System.Single
---@class FairyGUI.TweenValue : System.Object
local m = {}

---@return System.Void
function m:SetZero()end
FairyGUI = {}
FairyGUI.TweenValue = m
return m
