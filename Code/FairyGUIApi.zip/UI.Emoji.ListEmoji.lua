---@field public List_Emoji FairyGUI.GList
---@class UI.Emoji.ListEmoji
local m = {}

UI = {}
UI.Emoji = {}
UI.Emoji.ListEmoji = m
return m
