---@field public Label_CoolTime FairyGUI.GTextField
---@field public Image_maskCircle FairyGUI.GImage
---@field public Image_maskRect FairyGUI.GImage
---@class UI.CoolDown.DlgCoolTime
local m = {}

UI = {}
UI.CoolDown = {}
UI.CoolDown.DlgCoolTime = m
return m
