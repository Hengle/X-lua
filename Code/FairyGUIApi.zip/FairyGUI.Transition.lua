---@field public invalidateBatchingEveryFrame System.Boolean
---@field public name System.String
---@field public playing System.Boolean
---@field public timeScale System.Single
---@field public ignoreEngineTimeScale System.Boolean
---@class FairyGUI.Transition : System.Object
local m = {}

---@overload fun() : System.Void
---@overload fun() : System.Void
---@overload fun() : System.Void
---@return System.Void
function m:Play()end
---@overload fun() : System.Void
---@overload fun() : System.Void
---@return System.Void
function m:PlayReverse()end
---@param value System.Int32
---@return System.Void
function m:ChangePlayTimes(value)end
---@param autoPlay System.Boolean
---@param times System.Int32
---@param delay System.Single
---@return System.Void
function m:SetAutoPlay(autoPlay,times,delay)end
---@overload fun() : System.Void
---@return System.Void
function m:Stop()end
---@param paused System.Boolean
---@return System.Void
function m:SetPaused(paused)end
---@return System.Void
function m:Dispose()end
---@param label System.String
---@param aParams System.Object[]
---@return System.Void
function m:SetValue(label,aParams)end
---@param label System.String
---@param callback FairyGUI.TransitionHook
---@return System.Void
function m:SetHook(label,callback)end
---@return System.Void
function m:ClearHooks()end
---@param label System.String
---@param newTarget FairyGUI.GObject
---@return System.Void
function m:SetTarget(label,newTarget)end
---@param label System.String
---@param value System.Single
---@return System.Void
function m:SetDuration(label,value)end
---@param label System.String
---@return System.Single
function m:GetLabelTime(label)end
---@param tweener FairyGUI.GTweener
---@return System.Void
function m:OnTweenStart(tweener)end
---@param tweener FairyGUI.GTweener
---@return System.Void
function m:OnTweenUpdate(tweener)end
---@param tweener FairyGUI.GTweener
---@return System.Void
function m:OnTweenComplete(tweener)end
---@param buffer FairyGUI.Utils.ByteBuffer
---@return System.Void
function m:Setup(buffer)end
FairyGUI = {}
FairyGUI.Transition = m
return m
