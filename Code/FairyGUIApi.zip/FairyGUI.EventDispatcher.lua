---@class FairyGUI.EventDispatcher : System.Object
local m = {}

---@overload fun(strType : System.String,callback : FairyGUI.EventCallback1) : System.Void
---@param strType System.String
---@param callback FairyGUI.EventCallback1
---@return System.Void
function m:AddEventListener(strType,callback)end
---@overload fun(strType : System.String,callback : FairyGUI.EventCallback1) : System.Void
---@param strType System.String
---@param callback FairyGUI.EventCallback1
---@return System.Void
function m:RemoveEventListener(strType,callback)end
---@overload fun() : System.Void
---@return System.Void
function m:RemoveEventListeners()end
---@overload fun(strType : System.String) : System.Boolean
---@overload fun(strType : System.String) : System.Boolean
---@overload fun(strType : System.String) : System.Boolean
---@param strType System.String
---@return System.Boolean
function m:DispatchEvent(strType)end
---@param strType System.String
---@param data System.Object
---@return System.Boolean
function m:BubbleEvent(strType,data)end
---@param strType System.String
---@param data System.Object
---@return System.Boolean
function m:BroadcastEvent(strType,data)end
FairyGUI = {}
FairyGUI.EventDispatcher = m
return m
