---@field public layout FairyGUI.GroupLayoutType
---@field public lineGap System.Int32
---@field public columnGap System.Int32
---@class FairyGUI.GGroup : FairyGUI.GObject
local m = {}

---@param childSizeChanged System.Boolean
---@return System.Void
function m:SetBoundsChangedFlag(childSizeChanged)end
---@return System.Void
function m:EnsureBoundsCorrect()end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_BeforeAdd(buffer,beginPos)end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_AfterAdd(buffer,beginPos)end
FairyGUI = {}
FairyGUI.GGroup = m
return m
