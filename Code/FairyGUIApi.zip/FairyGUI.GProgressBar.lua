---@field public titleType FairyGUI.ProgressTitleType
---@field public max System.Double
---@field public value System.Double
---@field public reverse System.Boolean
---@class FairyGUI.GProgressBar : FairyGUI.GComponent
local m = {}

---@param value System.Double
---@param duration System.Single
---@return FairyGUI.GTweener
function m:TweenValue(value,duration)end
---@param newValue System.Double
---@return System.Void
function m:Update(newValue)end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_AfterAdd(buffer,beginPos)end
---@return System.Void
function m:Dispose()end
FairyGUI = {}
FairyGUI.GProgressBar = m
return m
