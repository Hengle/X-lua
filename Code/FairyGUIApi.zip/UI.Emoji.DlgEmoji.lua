---@field public List_Chats FairyGUI.GList
---@field public Button_SEmoji FairyGUI.GButton
---@field public Button_SendEmoji FairyGUI.GButton
---@field public TextField_Emoji FairyGUI.GTextField
---@field public Button_SIOS FairyGUI.GButton
---@field public Button_SendIOS FairyGUI.GButton
---@field public TextField_IOS FairyGUI.GTextField
---@class UI.Emoji.DlgEmoji
local m = {}

UI = {}
UI.Emoji = {}
UI.Emoji.DlgEmoji = m
return m
