---@field public List_EmojiIOS FairyGUI.GList
---@class UI.MEmoji.ListEmojiIOS
local m = {}

UI = {}
UI.MEmoji = {}
UI.MEmoji.ListEmojiIOS = m
return m
