---@field public List_Chats FairyGUI.GList
---@field public Button_SEmoji FairyGUI.GButton
---@field public Button_SendEmoji FairyGUI.GButton
---@field public TextInput_Emoji FairyGUI.GTextInput
---@field public Button_SIOS FairyGUI.GButton
---@field public Button_SendIOS FairyGUI.GButton
---@field public TextInput_IOS FairyGUI.GTextInput
---@class UI.MEmoji.DlgEmoji
local m = {}

UI = {}
UI.MEmoji = {}
UI.MEmoji.DlgEmoji = m
return m
