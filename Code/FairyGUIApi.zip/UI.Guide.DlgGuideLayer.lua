---@field public Graph_Window FairyGUI.GGraph
---@class UI.Guide.DlgGuideLayer
local m = {}

UI = {}
UI.Guide = {}
UI.Guide.DlgGuideLayer = m
return m
