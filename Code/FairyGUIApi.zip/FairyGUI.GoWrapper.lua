---@field public supportStencil System.Boolean
---@field public wrapTarget UnityEngine.GameObject
---@field public renderingOrder System.Int32
---@field public layer System.Int32
---@class FairyGUI.GoWrapper : FairyGUI.DisplayObject
local m = {}

---@param target UnityEngine.GameObject
---@param cloneMaterial System.Boolean
---@return System.Void
function m:setWrapTarget(target,cloneMaterial)end
---@param target UnityEngine.GameObject
---@param cloneMaterial System.Boolean
---@return System.Void
function m:SetWrapTarget(target,cloneMaterial)end
---@return System.Void
function m:CacheRenderers()end
---@param context FairyGUI.UpdateContext
---@return System.Void
function m:Update(context)end
---@return System.Void
function m:Dispose()end
FairyGUI = {}
FairyGUI.GoWrapper = m
return m
