---@field public changeOnClick System.Boolean
---@field public canDrag System.Boolean
---@field public onChanged FairyGUI.EventListener
---@field public onGripTouchEnd FairyGUI.EventListener
---@field public titleType FairyGUI.ProgressTitleType
---@field public max System.Double
---@field public value System.Double
---@class FairyGUI.GSlider : FairyGUI.GComponent
local m = {}

---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_AfterAdd(buffer,beginPos)end
FairyGUI = {}
FairyGUI.GSlider = m
return m
