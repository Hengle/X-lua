---@field public type System.String
---@field public data System.Object
---@field public sender FairyGUI.EventDispatcher
---@field public initiator System.Object
---@field public inputEvent FairyGUI.InputEvent
---@field public isDefaultPrevented System.Boolean
---@class FairyGUI.EventContext : System.Object
local m = {}

---@return System.Void
function m:StopPropagation()end
---@return System.Void
function m:PreventDefault()end
---@return System.Void
function m:CaptureTouch()end
FairyGUI = {}
FairyGUI.EventContext = m
return m
