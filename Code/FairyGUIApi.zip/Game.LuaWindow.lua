---@class Game.LuaWindow : FairyGUI.Window
local m = {}

---@return Game.LuaWindow
function m.Get()end
---@param window Game.LuaWindow
---@return System.Void
function m.Release(window)end
---@return System.Void
function m.Destroy()end
---@param table XLua.LuaTable
---@return System.Void
function m:ConnectLua(table)end
---@return System.Void
function m:ShowImmediately()end
---@return System.Void
function m:Dispose()end
Game = {}
Game.LuaWindow = m
return m
