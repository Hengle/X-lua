---@field public catchCallbackExceptions System.Boolean
---@class FairyGUI.GTween : System.Object
local m = {}

---@overload fun(startValue : System.Single,endValue : System.Single,duration : System.Single) : FairyGUI.GTweener
---@overload fun(startValue : System.Single,endValue : System.Single,duration : System.Single) : FairyGUI.GTweener
---@overload fun(startValue : System.Single,endValue : System.Single,duration : System.Single) : FairyGUI.GTweener
---@overload fun(startValue : System.Single,endValue : System.Single,duration : System.Single) : FairyGUI.GTweener
---@param startValue System.Single
---@param endValue System.Single
---@param duration System.Single
---@return FairyGUI.GTweener
function m.To(startValue,endValue,duration)end
---@param startValue System.Double
---@param endValue System.Double
---@param duration System.Single
---@return FairyGUI.GTweener
function m.ToDouble(startValue,endValue,duration)end
---@param delay System.Single
---@return FairyGUI.GTweener
function m.DelayedCall(delay)end
---@param startValue UnityEngine.Vector3
---@param amplitude System.Single
---@param duration System.Single
---@return FairyGUI.GTweener
function m.Shake(startValue,amplitude,duration)end
---@overload fun(target : System.Object) : System.Boolean
---@param target System.Object
---@return System.Boolean
function m.IsTweening(target)end
---@overload fun(target : System.Object) : System.Void
---@overload fun(target : System.Object) : System.Void
---@param target System.Object
---@return System.Void
function m.Kill(target)end
---@overload fun(target : System.Object) : FairyGUI.GTweener
---@param target System.Object
---@return FairyGUI.GTweener
function m.GetTween(target)end
---@return System.Void
function m.Clean()end
FairyGUI = {}
FairyGUI.GTween = m
return m
