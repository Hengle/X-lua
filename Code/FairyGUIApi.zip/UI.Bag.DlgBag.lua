---@field public List_BagGrid FairyGUI.GList
---@field public Loader_Selected FairyGUI.GLoader
---@field public Label_Name FairyGUI.GTextField
---@class UI.Bag.DlgBag
local m = {}

UI = {}
UI.Bag = {}
UI.Bag.DlgBag = m
return m
