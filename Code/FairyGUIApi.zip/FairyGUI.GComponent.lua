---@field public rootContainer FairyGUI.Container
---@field public container FairyGUI.Container
---@field public scrollPane FairyGUI.ScrollPane
---@field public onDrop FairyGUI.EventListener
---@field public fairyBatching System.Boolean
---@field public opaque System.Boolean
---@field public margin FairyGUI.Margin
---@field public childrenRenderOrder FairyGUI.ChildrenRenderOrder
---@field public apexIndex System.Int32
---@field public numChildren System.Int32
---@field public Controllers System.Collections.Generic.List`1[[FairyGUI.Controller, Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]
---@field public clipSoftness UnityEngine.Vector2
---@field public mask FairyGUI.DisplayObject
---@field public reversedMask System.Boolean
---@field public baseUserData System.String
---@field public viewWidth System.Single
---@field public viewHeight System.Single
---@class FairyGUI.GComponent : FairyGUI.GObject
local m = {}

---@return System.Void
function m:Dispose()end
---@param childChanged System.Boolean
---@return System.Void
function m:InvalidateBatchingState(childChanged)end
---@param child FairyGUI.GObject
---@return FairyGUI.GObject
function m:AddChild(child)end
---@param child FairyGUI.GObject
---@param index System.Int32
---@return FairyGUI.GObject
function m:AddChildAt(child,index)end
---@overload fun(child : FairyGUI.GObject) : FairyGUI.GObject
---@param child FairyGUI.GObject
---@return FairyGUI.GObject
function m:RemoveChild(child)end
---@overload fun(index : System.Int32) : FairyGUI.GObject
---@param index System.Int32
---@return FairyGUI.GObject
function m:RemoveChildAt(index)end
---@overload fun() : System.Void
---@return System.Void
function m:RemoveChildren()end
---@param index System.Int32
---@return FairyGUI.GObject
function m:GetChildAt(index)end
---@param name System.String
---@return FairyGUI.GObject
function m:GetChild(name)end
---@param name System.String
---@return FairyGUI.GObject
function m:GetVisibleChild(name)end
---@param group FairyGUI.GGroup
---@param name System.String
---@return FairyGUI.GObject
function m:GetChildInGroup(group,name)end
---@return FairyGUI.GObject[]
function m:GetChildren()end
---@param child FairyGUI.GObject
---@return System.Int32
function m:GetChildIndex(child)end
---@param child FairyGUI.GObject
---@param index System.Int32
---@return System.Void
function m:SetChildIndex(child,index)end
---@param child FairyGUI.GObject
---@param index System.Int32
---@return System.Int32
function m:SetChildIndexBefore(child,index)end
---@param child1 FairyGUI.GObject
---@param child2 FairyGUI.GObject
---@return System.Void
function m:SwapChildren(child1,child2)end
---@param index1 System.Int32
---@param index2 System.Int32
---@return System.Void
function m:SwapChildrenAt(index1,index2)end
---@param obj FairyGUI.GObject
---@return System.Boolean
function m:IsAncestorOf(obj)end
---@param controller FairyGUI.Controller
---@return System.Void
function m:AddController(controller)end
---@param index System.Int32
---@return FairyGUI.Controller
function m:GetControllerAt(index)end
---@param name System.String
---@return FairyGUI.Controller
function m:GetController(name)end
---@param c FairyGUI.Controller
---@return System.Void
function m:RemoveController(c)end
---@param index System.Int32
---@return FairyGUI.Transition
function m:GetTransitionAt(index)end
---@param name System.String
---@return FairyGUI.Transition
function m:GetTransition(name)end
---@param child FairyGUI.GObject
---@return System.Boolean
function m:IsChildInView(child)end
---@return System.Int32
function m:GetFirstChildInView()end
---@param c FairyGUI.Controller
---@return System.Void
function m:HandleControllerChanged(c)end
---@return System.Void
function m:SetBoundsChangedFlag()end
---@return System.Void
function m:EnsureBoundsCorrect()end
---@return System.Void
function m:ConstructFromResource()end
---@param xml FairyGUI.Utils.XML
---@return System.Void
function m:ConstructFromXML(xml)end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_AfterAdd(buffer,beginPos)end
FairyGUI = {}
FairyGUI.GComponent = m
return m
