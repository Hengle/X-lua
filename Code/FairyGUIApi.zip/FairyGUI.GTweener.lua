---@field public delay System.Single
---@field public duration System.Single
---@field public repeat System.Int32
---@field public target System.Object
---@field public userData System.Object
---@field public startValue FairyGUI.TweenValue
---@field public endValue FairyGUI.TweenValue
---@field public value FairyGUI.TweenValue
---@field public deltaValue FairyGUI.TweenValue
---@field public normalizedTime System.Single
---@field public completed System.Boolean
---@field public allCompleted System.Boolean
---@class FairyGUI.GTweener : System.Object
local m = {}

---@param value System.Single
---@return FairyGUI.GTweener
function m:SetDelay(value)end
---@param value System.Single
---@return FairyGUI.GTweener
function m:SetDuration(value)end
---@param value System.Single
---@return FairyGUI.GTweener
function m:SetBreakpoint(value)end
---@param value FairyGUI.EaseType
---@return FairyGUI.GTweener
function m:SetEase(value)end
---@param value System.Single
---@return FairyGUI.GTweener
function m:SetEasePeriod(value)end
---@param value System.Single
---@return FairyGUI.GTweener
function m:SetEaseOvershootOrAmplitude(value)end
---@param repeat System.Int32
---@param yoyo System.Boolean
---@return FairyGUI.GTweener
function m:SetRepeat(repeat,yoyo)end
---@param value System.Single
---@return FairyGUI.GTweener
function m:SetTimeScale(value)end
---@param value System.Boolean
---@return FairyGUI.GTweener
function m:SetIgnoreEngineTimeScale(value)end
---@param value System.Boolean
---@return FairyGUI.GTweener
function m:SetSnapping(value)end
---@overload fun(value : System.Object) : FairyGUI.GTweener
---@param value System.Object
---@return FairyGUI.GTweener
function m:SetTarget(value)end
---@param value System.Object
---@return FairyGUI.GTweener
function m:SetUserData(value)end
---@overload fun(callback : FairyGUI.GTweenCallback) : FairyGUI.GTweener
---@param callback FairyGUI.GTweenCallback
---@return FairyGUI.GTweener
function m:OnUpdate(callback)end
---@overload fun(callback : FairyGUI.GTweenCallback) : FairyGUI.GTweener
---@param callback FairyGUI.GTweenCallback
---@return FairyGUI.GTweener
function m:OnStart(callback)end
---@overload fun(callback : FairyGUI.GTweenCallback) : FairyGUI.GTweener
---@param callback FairyGUI.GTweenCallback
---@return FairyGUI.GTweener
function m:OnComplete(callback)end
---@param value FairyGUI.ITweenListener
---@return FairyGUI.GTweener
function m:SetListener(value)end
---@param paused System.Boolean
---@return FairyGUI.GTweener
function m:SetPaused(paused)end
---@param time System.Single
---@return System.Void
function m:Seek(time)end
---@param complete System.Boolean
---@return System.Void
function m:Kill(complete)end
FairyGUI = {}
FairyGUI.GTweener = m
return m
