---@field public ProgressBar_hp FairyGUI.GProgressBar
---@field public RichTextField_Name FairyGUI.GRichTextField
---@class UI.MHeadBar.ItemHeadBar
local m = {}

UI = {}
UI.MHeadBar = {}
UI.MHeadBar.ItemHeadBar = m
return m
