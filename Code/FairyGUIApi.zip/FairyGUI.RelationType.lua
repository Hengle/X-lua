---@class FairyGUI.RelationType
local m = {}

FairyGUI = {}
FairyGUI.RelationType = m
return m
