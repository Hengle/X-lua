---@field public showErrorSign System.Boolean
---@field public url System.String
---@field public icon System.String
---@field public align FairyGUI.AlignType
---@field public verticalAlign FairyGUI.VertAlignType
---@field public fill FairyGUI.FillType
---@field public shrinkOnly System.Boolean
---@field public autoSize System.Boolean
---@field public playing System.Boolean
---@field public frame System.Int32
---@field public timeScale System.Single
---@field public ignoreEngineTimeScale System.Boolean
---@field public material UnityEngine.Material
---@field public shader System.String
---@field public color UnityEngine.Color
---@field public fillMethod FairyGUI.FillMethod
---@field public fillOrigin System.Int32
---@field public fillClockwise System.Boolean
---@field public fillAmount System.Single
---@field public image FairyGUI.Image
---@field public movieClip FairyGUI.MovieClip
---@field public component FairyGUI.GComponent
---@field public texture FairyGUI.NTexture
---@field public filter FairyGUI.IFilter
---@field public blendMode FairyGUI.BlendMode
---@class FairyGUI.GLoader : FairyGUI.GObject
local m = {}

---@return System.Void
function m:Dispose()end
---@param time System.Single
---@return System.Void
function m:Advance(time)end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos System.Int32
---@return System.Void
function m:Setup_BeforeAdd(buffer,beginPos)end
FairyGUI = {}
FairyGUI.GLoader = m
return m
