---@field public handling FairyGUI.GObject
---@field public isEmpty System.Boolean
---@class FairyGUI.Relations : System.Object
local m = {}

---@overload fun(target : FairyGUI.GObject,relationType : FairyGUI.RelationType) : System.Void
---@param target FairyGUI.GObject
---@param relationType FairyGUI.RelationType
---@return System.Void
function m:Add(target,relationType)end
---@param target FairyGUI.GObject
---@param relationType FairyGUI.RelationType
---@return System.Void
function m:Remove(target,relationType)end
---@param target FairyGUI.GObject
---@return System.Boolean
function m:Contains(target)end
---@param target FairyGUI.GObject
---@return System.Void
function m:ClearFor(target)end
---@return System.Void
function m:ClearAll()end
---@param source FairyGUI.Relations
---@return System.Void
function m:CopyFrom(source)end
---@return System.Void
function m:Dispose()end
---@param dWidth System.Single
---@param dHeight System.Single
---@param applyPivot System.Boolean
---@return System.Void
function m:OnOwnerSizeChanged(dWidth,dHeight,applyPivot)end
---@param buffer FairyGUI.Utils.ByteBuffer
---@param parentToChild System.Boolean
---@return System.Void
function m:Setup(buffer,parentToChild)end
FairyGUI = {}
FairyGUI.Relations = m
return m
