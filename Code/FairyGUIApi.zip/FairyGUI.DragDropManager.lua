---@field public inst FairyGUI.DragDropManager
---@field public dragAgent FairyGUI.GLoader
---@field public dragging System.Boolean
---@class FairyGUI.DragDropManager : System.Object
local m = {}

---@param source FairyGUI.GObject
---@param icon System.String
---@param sourceData System.Object
---@param touchPointID System.Int32
---@return System.Void
function m:StartDrag(source,icon,sourceData,touchPointID)end
---@return System.Void
function m:Cancel()end
FairyGUI = {}
FairyGUI.DragDropManager = m
return m
