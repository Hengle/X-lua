---@field public x System.Single
---@field public y System.Single
---@field public keyCode UnityEngine.KeyCode
---@field public character System.Char
---@field public modifiers UnityEngine.EventModifiers
---@field public mouseWheelDelta System.Int32
---@field public touchId System.Int32
---@field public button System.Int32
---@field public position UnityEngine.Vector2
---@field public isDoubleClick System.Boolean
---@field public ctrl System.Boolean
---@field public shift System.Boolean
---@field public alt System.Boolean
---@class FairyGUI.InputEvent : System.Object
local m = {}

FairyGUI = {}
FairyGUI.InputEvent = m
return m
