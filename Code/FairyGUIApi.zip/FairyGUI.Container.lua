---@field public renderMode UnityEngine.RenderMode
---@field public renderCamera UnityEngine.Camera
---@field public opaque System.Boolean
---@field public clipSoftness System.Nullable`1[[UnityEngine.Vector4, UnityEngine.CoreModule, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]
---@field public hitArea FairyGUI.IHitTest
---@field public touchChildren System.Boolean
---@field public onUpdate FairyGUI.EventCallback0
---@field public reversedMask System.Boolean
---@field public numChildren System.Int32
---@field public clipRect System.Nullable`1[[UnityEngine.Rect, UnityEngine.CoreModule, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]
---@field public mask FairyGUI.DisplayObject
---@field public touchable System.Boolean
---@field public contentRect UnityEngine.Rect
---@field public fairyBatching System.Boolean
---@class FairyGUI.Container : FairyGUI.DisplayObject
local m = {}

---@param child FairyGUI.DisplayObject
---@return FairyGUI.DisplayObject
function m:AddChild(child)end
---@param child FairyGUI.DisplayObject
---@param index System.Int32
---@return FairyGUI.DisplayObject
function m:AddChildAt(child,index)end
---@param child FairyGUI.DisplayObject
---@return System.Boolean
function m:Contains(child)end
---@param index System.Int32
---@return FairyGUI.DisplayObject
function m:GetChildAt(index)end
---@param name System.String
---@return FairyGUI.DisplayObject
function m:GetChild(name)end
---@param child FairyGUI.DisplayObject
---@return System.Int32
function m:GetChildIndex(child)end
---@overload fun(child : FairyGUI.DisplayObject) : FairyGUI.DisplayObject
---@param child FairyGUI.DisplayObject
---@return FairyGUI.DisplayObject
function m:RemoveChild(child)end
---@overload fun(index : System.Int32) : FairyGUI.DisplayObject
---@param index System.Int32
---@return FairyGUI.DisplayObject
function m:RemoveChildAt(index)end
---@overload fun() : System.Void
---@return System.Void
function m:RemoveChildren()end
---@param child FairyGUI.DisplayObject
---@param index System.Int32
---@return System.Void
function m:SetChildIndex(child,index)end
---@param child1 FairyGUI.DisplayObject
---@param child2 FairyGUI.DisplayObject
---@return System.Void
function m:SwapChildren(child1,child2)end
---@param index1 System.Int32
---@param index2 System.Int32
---@return System.Void
function m:SwapChildrenAt(index1,index2)end
---@param indice System.Collections.Generic.List`1[[System.Int32, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]
---@param objs System.Collections.Generic.List`1[[FairyGUI.DisplayObject, Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]
---@return System.Void
function m:ChangeChildrenOrder(indice,objs)end
---@param targetSpace FairyGUI.DisplayObject
---@return UnityEngine.Rect
function m:GetBounds(targetSpace)end
---@return UnityEngine.Camera
function m:GetRenderCamera()end
---@param stagePoint UnityEngine.Vector2
---@param forTouch System.Boolean
---@return FairyGUI.DisplayObject
function m:HitTest(stagePoint,forTouch)end
---@return UnityEngine.Vector2
function m:GetHitTestLocalPoint()end
---@param obj FairyGUI.DisplayObject
---@return System.Boolean
function m:IsAncestorOf(obj)end
---@param childrenChanged System.Boolean
---@return System.Void
function m:InvalidateBatchingState(childrenChanged)end
---@param value System.Int32
---@return System.Void
function m:SetChildrenLayer(value)end
---@param context FairyGUI.UpdateContext
---@return System.Void
function m:Update(context)end
---@return System.Void
function m:Dispose()end
FairyGUI = {}
FairyGUI.Container = m
return m
