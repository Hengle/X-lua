---@field public Loader_icon MyLoader
---@field public RichTextField_LMsg FairyGUI.GRichTextField
---@class UI.MEmoji.ItemChatLeft
local m = {}

UI = {}
UI.MEmoji = {}
UI.MEmoji.ItemChatLeft = m
return m
