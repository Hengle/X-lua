---@field public onScroll FairyGUI.EventListener
---@field public onScrollEnd FairyGUI.EventListener
---@field public onPullDownRelease FairyGUI.EventListener
---@field public onPullUpRelease FairyGUI.EventListener
---@field public draggingPane FairyGUI.ScrollPane
---@field public owner FairyGUI.GComponent
---@field public hzScrollBar FairyGUI.GScrollBar
---@field public vtScrollBar FairyGUI.GScrollBar
---@field public header FairyGUI.GComponent
---@field public footer FairyGUI.GComponent
---@field public bouncebackEffect System.Boolean
---@field public touchEffect System.Boolean
---@field public inertiaDisabled System.Boolean
---@field public softnessOnTopOrLeftSide System.Boolean
---@field public scrollStep System.Single
---@field public snapToItem System.Boolean
---@field public pageMode System.Boolean
---@field public pageController FairyGUI.Controller
---@field public mouseWheelEnabled System.Boolean
---@field public decelerationRate System.Single
---@field public percX System.Single
---@field public percY System.Single
---@field public posX System.Single
---@field public posY System.Single
---@field public isBottomMost System.Boolean
---@field public isRightMost System.Boolean
---@field public currentPageX System.Int32
---@field public currentPageY System.Int32
---@field public scrollingPosX System.Single
---@field public scrollingPosY System.Single
---@field public contentWidth System.Single
---@field public contentHeight System.Single
---@field public viewWidth System.Single
---@field public viewHeight System.Single
---@class FairyGUI.ScrollPane : FairyGUI.EventDispatcher
local m = {}

---@param buffer FairyGUI.Utils.ByteBuffer
---@return System.Void
function m:Setup(buffer)end
---@return System.Void
function m:Dispose()end
---@param value System.Single
---@param ani System.Boolean
---@return System.Void
function m:SetPercX(value,ani)end
---@param value System.Single
---@param ani System.Boolean
---@return System.Void
function m:SetPercY(value,ani)end
---@param value System.Single
---@param ani System.Boolean
---@return System.Void
function m:SetPosX(value,ani)end
---@param value System.Single
---@param ani System.Boolean
---@return System.Void
function m:SetPosY(value,ani)end
---@param value System.Int32
---@param ani System.Boolean
---@return System.Void
function m:SetCurrentPageX(value,ani)end
---@param value System.Int32
---@param ani System.Boolean
---@return System.Void
function m:SetCurrentPageY(value,ani)end
---@overload fun() : System.Void
---@return System.Void
function m:ScrollTop()end
---@overload fun() : System.Void
---@return System.Void
function m:ScrollBottom()end
---@overload fun() : System.Void
---@return System.Void
function m:ScrollUp()end
---@overload fun() : System.Void
---@return System.Void
function m:ScrollDown()end
---@overload fun() : System.Void
---@return System.Void
function m:ScrollLeft()end
---@overload fun() : System.Void
---@return System.Void
function m:ScrollRight()end
---@overload fun(obj : FairyGUI.GObject) : System.Void
---@overload fun(obj : FairyGUI.GObject) : System.Void
---@overload fun(obj : FairyGUI.GObject) : System.Void
---@param obj FairyGUI.GObject
---@return System.Void
function m:ScrollToView(obj)end
---@param obj FairyGUI.GObject
---@return System.Boolean
function m:IsChildInView(obj)end
---@return System.Void
function m:CancelDragging()end
---@param size System.Int32
---@return System.Void
function m:LockHeader(size)end
---@param size System.Int32
---@return System.Void
function m:LockFooter(size)end
FairyGUI = {}
FairyGUI.ScrollPane = m
return m
