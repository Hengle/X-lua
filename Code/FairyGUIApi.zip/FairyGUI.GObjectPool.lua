---@field public initCallback FairyGUI.GObjectPool+InitCallbackDelegate
---@field public count System.Int32
---@class FairyGUI.GObjectPool : System.Object
local m = {}

---@return System.Void
function m:Clear()end
---@param url System.String
---@return FairyGUI.GObject
function m:GetObject(url)end
---@param obj FairyGUI.GObject
---@return System.Void
function m:ReturnObject(obj)end
FairyGUI = {}
FairyGUI.GObjectPool = m
return m
