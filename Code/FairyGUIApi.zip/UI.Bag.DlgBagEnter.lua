---@field public Button_Enter FairyGUI.GButton
---@class UI.Bag.DlgBagEnter
local m = {}

UI = {}
UI.Bag = {}
UI.Bag.DlgBagEnter = m
return m
