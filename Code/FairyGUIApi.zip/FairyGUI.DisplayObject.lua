---@field public name System.String
---@field public onPaint FairyGUI.EventCallback0
---@field public gOwner FairyGUI.GObject
---@field public id System.UInt32
---@field public parent FairyGUI.Container
---@field public gameObject UnityEngine.GameObject
---@field public cachedTransform UnityEngine.Transform
---@field public graphics FairyGUI.NGraphics
---@field public paintingGraphics FairyGUI.NGraphics
---@field public onClick FairyGUI.EventListener
---@field public onRightClick FairyGUI.EventListener
---@field public onTouchBegin FairyGUI.EventListener
---@field public onTouchMove FairyGUI.EventListener
---@field public onTouchEnd FairyGUI.EventListener
---@field public onRollOver FairyGUI.EventListener
---@field public onRollOut FairyGUI.EventListener
---@field public onMouseWheel FairyGUI.EventListener
---@field public onAddedToStage FairyGUI.EventListener
---@field public onRemovedFromStage FairyGUI.EventListener
---@field public onKeyDown FairyGUI.EventListener
---@field public onClickLink FairyGUI.EventListener
---@field public alpha System.Single
---@field public grayed System.Boolean
---@field public visible System.Boolean
---@field public x System.Single
---@field public y System.Single
---@field public z System.Single
---@field public xy UnityEngine.Vector2
---@field public position UnityEngine.Vector3
---@field public width System.Single
---@field public height System.Single
---@field public size UnityEngine.Vector2
---@field public scaleX System.Single
---@field public scaleY System.Single
---@field public scale UnityEngine.Vector2
---@field public rotation System.Single
---@field public rotationX System.Single
---@field public rotationY System.Single
---@field public skew UnityEngine.Vector2
---@field public perspective System.Boolean
---@field public focalLength System.Int32
---@field public pivot UnityEngine.Vector2
---@field public location UnityEngine.Vector3
---@field public material UnityEngine.Material
---@field public shader System.String
---@field public renderingOrder System.Int32
---@field public layer System.Int32
---@field public isDisposed System.Boolean
---@field public topmost FairyGUI.Container
---@field public stage FairyGUI.Stage
---@field public worldSpaceContainer FairyGUI.Container
---@field public touchable System.Boolean
---@field public paintingMode System.Boolean
---@field public cacheAsBitmap System.Boolean
---@field public filter FairyGUI.IFilter
---@field public blendMode FairyGUI.BlendMode
---@field public home UnityEngine.Transform
---@class FairyGUI.DisplayObject : FairyGUI.EventDispatcher
local m = {}

---@param xv System.Single
---@param yv System.Single
---@return System.Void
function m:SetXY(xv,yv)end
---@param xv System.Single
---@param yv System.Single
---@param zv System.Single
---@return System.Void
function m:SetPosition(xv,yv,zv)end
---@param wv System.Single
---@param hv System.Single
---@return System.Void
function m:SetSize(wv,hv)end
---@return System.Void
function m:EnsureSizeCorrect()end
---@param xv System.Single
---@param yv System.Single
---@return System.Void
function m:SetScale(xv,yv)end
---@param requestorId System.Int32
---@param margin System.Nullable`1[[FairyGUI.Margin, Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]
---@return System.Void
function m:EnterPaintingMode(requestorId,margin)end
---@param requestorId System.Int32
---@return System.Void
function m:LeavePaintingMode(requestorId)end
---@param targetSpace FairyGUI.DisplayObject
---@return UnityEngine.Rect
function m:GetBounds(targetSpace)end
---@param point UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:GlobalToLocal(point)end
---@param point UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:LocalToGlobal(point)end
---@param worldPoint UnityEngine.Vector3
---@param direction UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:WorldToLocal(worldPoint,direction)end
---@param point UnityEngine.Vector2
---@param targetSpace FairyGUI.DisplayObject
---@return UnityEngine.Vector2
function m:TransformPoint(point,targetSpace)end
---@param rect UnityEngine.Rect
---@param targetSpace FairyGUI.DisplayObject
---@return UnityEngine.Rect
function m:TransformRect(rect,targetSpace)end
---@return System.Void
function m:RemoveFromParent()end
---@return System.Void
function m:InvalidateBatchingState()end
---@param context FairyGUI.UpdateContext
---@return System.Void
function m:Update(context)end
---@return System.Void
function m:Dispose()end
FairyGUI = {}
FairyGUI.DisplayObject = m
return m
